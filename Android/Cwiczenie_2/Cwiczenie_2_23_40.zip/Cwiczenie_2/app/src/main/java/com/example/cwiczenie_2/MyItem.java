package com.example.cwiczenie_2;

import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

public class MyItem {
    private TextView red;
    private TextView green;
    private TextView blue;

    private int ired;
    private int igreen;
    private int iblue;

    private SeekBar seekBarRed;
    private SeekBar seekBarGreen;
    private SeekBar seekBarBlue;
    private View view;

    private int color;

    public MyItem(){

    }
}
